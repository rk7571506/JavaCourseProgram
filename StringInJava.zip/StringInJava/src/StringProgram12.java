
public class StringProgram12 {

	public static void main(String[] args) {
		
		//individual character of a string cannot be accessed.
		/*
		 1. charAt(index);
		 2. toCharArray(); 
		 */
		String s = "RAMAMOHAN";
		
		System.out.println(s.charAt(2));//M
		System.out.println(s.charAt(3));//A
		
		char a[] = s.toCharArray(); //convert string into an array of character.
		for(int i=0;i<a.length;i++){
			System.out.print(a[i]+" "); // R A M A M O H A N
		}
		System.out.println();
	}
}


public class StringProgram5 {

	public static void main(String[] args) {
		
		String s1 = "Rama"; //constant pool
		String s2 = new String("Rama"); //non constant pool
		
		if(s1==s2)
		{
			System.out.println("Reference is equal.");
		}
		else
		{
			System.out.println("Reference is not equal");
		}

	}

}

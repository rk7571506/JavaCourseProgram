
public class StringBufferProgram1 {

	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("RAMA");
		System.out.println(sb);//RAMA
		System.out.println(sb.capacity()); //20
		System.out.println(sb.length());//4
		sb.append("sita");
		System.out.println(sb);//RAMAsita
		
		sb.insert(2, '$');
		System.out.println(sb);//RA$MAsita
		
		sb.insert(2, "***");
		System.out.println(sb);

		System.out.println(sb.reverse());
		
		
		StringBuffer sb1 = new StringBuffer(8);
		System.out.println(sb1.capacity()); //8
		
		sb1.ensureCapacity(24);
		System.out.println(sb1.capacity());//24
		
		sb1.append("RAMA");
		System.out.println(sb1);//RAMA
		
		
		StringBuffer sb2 = new StringBuffer();
		System.out.println(sb2.capacity()); //16
		
		sb2.ensureCapacity(24);
		System.out.println(sb2.capacity());//34
		
		sb2.append("RAMA");
		System.out.println(sb2);
		
	}

}

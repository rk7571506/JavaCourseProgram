/*
 * Upto jdk 1.7, only integers were allowed. From jdk 1.8 onwards even Strings are permitted in switch case.
 * */
public class SwitchCaseInJavaString {

	public static void main(String[] args) {
	
		String s = "RAMA";
		
		switch(s)
		{
			case "Rama":
				System.out.println("I am Rama");
				break;
			case "RAMA":
				System.out.println("I am RAMA");
				break;
			case "Shyam":
				System.out.println("I am Shyam");
				break;
			default:
				System.out.println("Ravi Ranjan");
		}

	}

}

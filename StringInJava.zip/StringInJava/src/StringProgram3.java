
public class StringProgram3 {

	public static void main(String[] args) {
		String s1 = new String("RAMA"); //Non constant pool
		String s2 = new String("RAMA"); //Non constant pool
		
		if(s1==s2)
		{
			System.out.println("Reference is Equal");
		}
		else
		{
			System.out.println("Reference is not equal");
		}
		
		
		/* intern() -> It is used to create a copy of the string present in non-constant pool  into the constant pool region*/
		
		String s3 = s1.intern();//constant pool
		String s4 = s1.intern();//constant pool

		if(s3==s4)
			System.out.println("reference is equal.");
		else
			System.out.println("reference is not equal.");
	}

}

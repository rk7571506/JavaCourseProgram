
public class StringProgram8 {

	public static void main(String[] args) {
		String s1 = "RAMA"; //constant pool.
 		String s2 = "SITA"; //constant pool.
		
 		String s3 = "RAMA"+"SITA"; //constant pool
 		String s4 = "RAMA"+"SITA"; //constant pool
 		
 		if(s3==s4)
 			System.out.println("Reference is equal.");
 		else
 			System.out.println("Reference is not equal.");
 		
 		if(s3.equals(s4))
 			System.out.println("Values is equal");
 		else
 			System.out.println("Values is not equal.");
		 

	}

}


public class StringProgram4 {

	public static void main(String[] args) {
		String s1 = new String("RAMA"); //Non constant pool
		String s2 = new String("RAMA"); //Non constant pool
		
		if(s1.equals(s2))
		{
			System.out.println("Values is Equal");
		}
		else
		{
			System.out.println("Values is not equal");
		}

	}

}

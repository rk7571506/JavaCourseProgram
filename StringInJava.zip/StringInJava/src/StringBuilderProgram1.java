
public class StringBuilderProgram1 {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("RAMA");
		System.out.println(sb);//RAMA
		System.out.println(sb.capacity()); //20
		System.out.println(sb.length());//4
		sb.append("sita");
		System.out.println(sb);//RAMAsita
		
		sb.insert(2, '$');
		System.out.println(sb);//RA$MAsita
		
		sb.insert(2, "***");
		System.out.println(sb);

		System.out.println(sb.reverse());

	}

}

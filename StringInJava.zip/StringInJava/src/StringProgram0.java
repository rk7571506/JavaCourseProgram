
public class StringProgram0 {

	public static void main(String[] args) {
		//String class Has over 60 method & 13 constructor.
		
		/*
		 String use -> ""
		 char use -> ''
		  */
		
		//	Creation of String.
		
		String s1 = "RAMA";
		String s2 = new String("RAMA");
		System.out.println(s1);//RAMA
		System.out.println(s2);//RAMA
		
		
		char a[] = {'A','B','C'};
		System.out.println(a);//ABC
		
		String b = new String(a);
		System.out.println(b);//ABC
		
		
		//finding string length:-
		System.out.println(s1.length());//4
		System.out.println(b.length());//3
	}

}

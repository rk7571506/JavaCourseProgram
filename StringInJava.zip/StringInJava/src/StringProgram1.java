
public class StringProgram1 {

	public static void main(String[] args) {
		
		//String is immutable. -> can't change.(Using String Class)
		String s1 = "RAMA"; //constant pool
		String s2 = "RAMA"; //constant pool
		
		if(s1==s2)
		{
			System.out.println("Reference is Equal");
		}
		else
		{
			System.out.println("Reference is not equal");
		}
		
		
		/*
		 When we use String creation using a new keyword it will created in non-constant pool.
		 and when we are not using the new keyword the String is created in constant pool.
		 
		 String s = "RAMA"; // constant pool.
		 String s  = new String("RAMA")//non-constant pool.
		 */
	
	}

}

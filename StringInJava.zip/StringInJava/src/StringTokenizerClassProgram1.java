import java.util.StringTokenizer;

public class StringTokenizerClassProgram1 {

	public static void main(String[] args) {
		
		/*
		        It is used to chop a large string at a specified character in order to provide tokens. 
		  */
		StringTokenizer s = new StringTokenizer("ABC for technology trainning");
		
		while(s.hasMoreTokens()==true)
		{
			System.out.println(s.nextToken());
		}
		
		System.out.println("*************************************************");
		
		StringTokenizer s1 = new StringTokenizer("A$B$C fo$r techn$olog$y trai$nn$ing","$");
		
		while(s1.hasMoreTokens()==true)
		{
			System.out.println(s1.nextToken());
		}
	}

}

/*
  1. compareTo() method.
   returns +ve, -ve, zero values. 
  2. compareToIgnoreCase() method
 */
public class StringProgram11 {

	public static void main(String[] args) {
	
		//Case1: if both string same character then it return 0.
		String s1 = "RAMA";
		String s2 = "RAMA";
		String s3 = "rama";
		
		System.out.println(s1.compareTo(s2)); //0
		System.out.println(s1.compareToIgnoreCase(s3)); //0
		
		//case2: if first string length is greter then the second string then it returns positive integer.[difference between length]
		
		String s4 = "RAMASITA";
		String s5 = "RAMA";		
		System.out.println(s4.compareTo(s5));//4
		
		//case3: if first string length is less then the second string then it returns positive integer.[difference between length]
		System.out.println(s5.compareTo(s4)); //-4
		
		//case4: if both the string have same length but any character mismatch then it will return the difference of Character.
		
		String s6 = "RAJA" ;
		/*
		 M - > 77 J - > 74 , 
		 s5-s6  -> 77-74 = 3; 
		  */
		
		System.out.println(s5.compareTo(s6)); //3
		System.out.println(s6.compareTo(s5)); //-3
	}
}

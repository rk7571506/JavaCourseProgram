
public class StringProgram7 {

	public static void main(String[] args) {
		String s1 = "SITA"; //constant pool
		String s2 = new String("sita"); //non - constant pool
		
		if(s1.equals(s2))
			System.out.println("Using equals() method Values are Equal");
		else
			System.out.println("Using equals() method Values are Equal");
		
		
		if(s1.equalsIgnoreCase(s2))
			System.out.println("Using equalsIgnoreCase() method Values is Equal");
		else
			System.out.println("Using equalsIgnoreCase() method Values not is Equal");

	}

}

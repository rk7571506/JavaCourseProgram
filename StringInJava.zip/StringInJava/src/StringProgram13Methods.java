
public class StringProgram13Methods {

	public static void main(String[] args) {
		
		String s  = "RajaRamMohanRoy";
		String s1 = "RAMShyamRAMRAM";
		
		System.out.println(s);//RajaRamMohanRoy
		System.out.println(s.toLowerCase());//rajarammohanroy
		System.out.println(s.toUpperCase());//RAJARAMMOHANROY
		System.out.println(s.charAt(2));//j
		System.out.println(s.indexOf('R'));//0
		System.out.println(s.indexOf('r'));//-1
		System.out.println(s.indexOf("Ram"));//4
		System.out.println(s.indexOf('R', 5));//12 -> searching 'R' from 5th index.
		System.out.println(s.indexOf('r', 5));//-1 ->not found case
	
		System.out.println(s1.indexOf("RAM",10));//11
		System.out.println(s1.indexOf("RaM",10));//-1 ->not found
		
		
		System.out.println(s.lastIndexOf('R'));//12
		System.out.println(s1.lastIndexOf("RAM"));//11
		System.out.println(s1.lastIndexOf('R', 5));//0
		
		System.out.println(s.substring(7));//MohanRoy
		System.out.println(s.substring(2, 7));//jaRam
		
		System.out.println(s.contains("Ram"));//true
		System.out.println(s.contains("Roj"));//false
		
		System.out.println(s.startsWith("Raja"));//true
		System.out.println(s.startsWith("Ram"));//false
		
		System.out.println(s.endsWith("Roy"));//true
		System.out.println(s.endsWith("Roj"));//false
		
		/*The java lang.string.trim()is a built-in function that eliminates leading and trailing spaces. 
		  The Unicode value of space character is �\u0020�. The trim() method in java checks this Unicode 
		  value before and after the string, if it exists then removes the spaces and returns the omitted string.*/
		
		String s2 = "   Ravi  Ranjan  Is Good Person.   "; //it includes only spaces.
		System.out.println(s2);
		String s3 = s2.trim(); /*Returns the copy of the String, by removing whitespaces at both ends. It does not affect whitespaces in the middle.*/
		System.out.println(s3);
	
		String s4 = "RajaRoyRahulRR";
		System.out.println(s4.replace('R', '$'));
		
		System.out.println(s3.replace(" ",""));
		String s5 = "	Ra		vi		i  l		";//it includes space & Tab also
		System.out.println(s5.replaceAll(" ", ""));
		System.out.println(s5.replaceAll("\\s", ""));
		
		/*
		 public int hashCode() � It returns hashcode of the given String. There is predefined formula to compute the 
		 hashcode of the String:
				s[0]*31^(n-1) + s[1]*31^(n-2) + ... + s[n-1]
				where,
				n - is the length of the String
				i - is the ith character of the string
		  */

		String s6 = "ab";
		System.out.println(s6.hashCode());//97*31^(2-1) + 98*31^(2-2) = 3105
		
		/*
		1. public int codePointAt(int index) � 
		           It takes as parameter a index which must be from 0 to length() � 1. 
		           and returns a character unicode point of a index.
		2. public int codePointBefore(int index) � 
		          It takes as parameter a index which must be from 0 to length() � 1. 
		          and returns a unicode point of a character just before the index .
	    3. public int codePointCount(int start_index, int end_index) � 
	    		It takes as parameter start_index and end_index and returns the count of 
	    		Unicode code points between the range. 
		 
		  */

		String s7 = "abccdef";
		
		System.out.println(s7.codePointAt(2)); //99
		System.out.println(s7.codePointBefore(2));//98
		System.out.println(s7.codePointCount(0,3));//3
		
		String s8 = "";
		System.out.println(s8.isEmpty());//true
		System.out.println(s7.isEmpty());//false
		
		String s9 = "AbcdERGFGgffklghg";
		String s10 = "Geeks for Geeks";
		System.out.println(s9.replaceAll("[A-Z]", "#"));
		System.out.println(s10.replaceFirst("Geeks", "Quiz"));
		System.out.println(s10.replaceAll("[a,e,i,o,u]", "*"));
		
		String s11 = "Ravi$Ra$nj$an";
		System.out.println(s11);
		String s12[] = s11.split("R");
		
		for(String t : s12)
		{
			System.out.print(t+" ");
		}
		System.out.println();
		String s13 = "Ravi Ranjan		Good";
		String s14[] = s13.split("\\s");
		System.out.println(s13);
		for(String t : s14)
		{
			System.out.print(t+" ");
		}
		
		System.out.println();
		
		// integer to String converter.
		
		int i = 2;
		int j = 3;
		System.out.println(i+j);
		String a = s.valueOf(i);
		String b = s.valueOf(j);
		System.out.println(a+b);
		
		
	}
}

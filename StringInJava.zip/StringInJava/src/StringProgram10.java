
public class StringProgram10 {

	public static void main(String[] args) {
		
		String s1 = "RAMA"; //constant pool
		System.out.println(s1); //RAMA
		
		s1.concat("SITA"); //RAMASITA
		
		System.out.println(s1); //RAMA
		
		String s2 = s1.concat("SITA"); //RAMASITA
		
		System.out.println(s1); // RAMA
		System.out.println(s2);//RAMASITA
		
		/*
		 Whenever by making use of concat() method, and immutable String is attempted to modefied then
		 existance String will not get modefied rather a new String object will be created.
		 */
	}
}

import java.math.BigInteger;

public class Concept3 {

	public static void main(String[] args) {
		
		BigInteger a = BigInteger.valueOf(40);
		BigInteger b = BigInteger.valueOf(23);
		BigInteger c = BigInteger.valueOf(40);
		//comapre a & b.
		/*
		 * return -1  -> less than
		 * return 0   -> equal
		 * return 1  -> grater than
		 * */
		System.out.println(a.compareTo(b)); //1
		System.out.println(b.compareTo(a)); //-1
		System.out.println(a.compareTo(c));//0
		
		//equals method.
		if(a.equals(c))
		{
			System.out.println("I am Equal");
		}
		else
		{
			System.out.println("I am not Equal");
		}
		
		/**************/
		if(a.equals(b))
		{
			System.out.println("I am Equal");
		}
		else
		{
			System.out.println("I am not Equal");
		}
	}

}

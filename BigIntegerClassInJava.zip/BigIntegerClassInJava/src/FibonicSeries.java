import java.math.BigInteger;

public class FibonicSeries {
	
	public static void calculateLargeFibo(long n)
	  {
		  BigInteger a = BigInteger.valueOf(0);
		  BigInteger b = BigInteger.valueOf(1);
		  BigInteger c = BigInteger.valueOf(1);
		  
		  if(n==1)
		  System.out.print(a+" ");
		  if(n>1){
			  System.out.print(a+" "+b+" ");  
		  for(int i=2;i<=n;i++)
		  {
			  c = a.add(b);
			  a = b;
			  b = c;
			  System.out.print(c+" ");
		  }
		  }
		  System.out.println();
		  
	  }

	public static void main(String[] args) {
		
		calculateLargeFibo(100);
		calculateLargeFibo(1);
		calculateLargeFibo(2);
		calculateLargeFibo(5);

	}

}

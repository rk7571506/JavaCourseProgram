import java.math.BigInteger;

/*Quick ways to check for prime number.
 * 
 * 1.) isProbablePrime(int certainty): 
 * 				A method in BigInteger class to check if a given number is prime. For certainty = 1, 
 * 				it return true if BigInteger is prime and false if BigInteger is composite.
 * 
 * 
 * */
public class Program1 {

	public static boolean checkPrime(int n)
	{
		int a = 1;
		
		BigInteger b = BigInteger.valueOf(n);
		
		return b.isProbablePrime(a);
		
	}
	
	public static void main(String[] args) {
		
		System.out.println(checkPrime(13)); //true
		System.out.println(checkPrime(6)); //false

	}

}

import java.math.BigInteger;

/*Find Next  Prime:-
 		1.) nextProbablePrime() :
 		 Another method present in BigInteger class. This functions returns the next Prime Number 
 		 greater than current BigInteger.Below is Java program to demonstrate above function.
 */

public class Program2 {

	public static long findNextPrime(long n)
	{
		BigInteger b = new BigInteger(String.valueOf(n)); // 	BigInteger b = new BigInteger(""+n); 
		
		return Long.parseLong(b.nextProbablePrime().toString());
	}
	
	
	public static BigInteger findNextPrime1(long n)
	{
		BigInteger b = new BigInteger(""+n); // 	BigInteger b = new BigInteger(""+n); 
		
		return b.nextProbablePrime();
	}
	public static void main(String[] args) {
		
		System.out.println(findNextPrime(13));//17
		System.out.println(findNextPrime(100)); //101		
		System.out.println(findNextPrime1(13));//17
		System.out.println(findNextPrime1(100)); //101

	}

}

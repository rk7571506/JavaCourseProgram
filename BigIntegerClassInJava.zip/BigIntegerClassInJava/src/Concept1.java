import java.math.BigInteger;

/*
 BigInteger class is used for mathematical operation which involves very big integer calculations that are 
 outside the limit of all available primitive data types.
 
 For example factorial of 100 contains 158 digits in it so we can�t store it in any primitive data 
 type available. We can store as large Integer as we want in it. There is no theoretical limit on the 
 upper bound of the range because memory is allocated dynamically but practically as memory is limited 
 you can store a number which has Integer.MAX_VALUE number of bits in it which should be sufficient to 
 store mostly all large values.
 
  */

public class Concept1 {

	public static BigInteger fact(int n)
	{
		BigInteger result = new BigInteger("1");
		
		for(int i=2;i<=n;i++){
			result = result.multiply(BigInteger.valueOf(i));
		}
		
		return result;
	}
	public static void main(String[] args) {
		
		System.out.println(fact(1000));
		
	}

}

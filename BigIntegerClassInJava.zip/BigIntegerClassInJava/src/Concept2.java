import java.math.BigInteger;

public class Concept2 {

	public static void main(String[] args) {
		
		//Declaration Of BigInteger.
		int a,b,c;
		BigInteger A,B,C;
		
		a =  54;
		b = 23;
		c = -13;
		A = BigInteger.valueOf(54);
		B = BigInteger.valueOf(37);
		C = BigInteger.valueOf(c);
		
		//Mathematical Operations For BigInteger
		
		System.out.println(A.add(B));
		System.out.println(A.subtract(B));
		System.out.println(A.multiply(B));
		System.out.println(A.divide(B));
		System.out.println(A.remainder(B));
		System.out.println(C.abs());//13
		
		//Also Declare As
		BigInteger D = new BigInteger("54");
		BigInteger E = new BigInteger("23");
		
		BigInteger F = D.add(E);
		System.out.println(F);//77
		
		
		//Defining Constant In BigInteger Class:-
		
		BigInteger G = BigInteger.ONE;
		BigInteger H = BigInteger.ZERO;
		BigInteger I = BigInteger.TEN;
		
		System.out.println(G+" "+H+" "+I);
		
		
		//also
		
		String s = "12345";
		BigInteger Q = BigInteger.valueOf(1);
		BigInteger J = new BigInteger(s);
		BigInteger N = Q.add(J);
		System.out.println(N);
		
		//Extraction of value from BigInteger.
		int x = Q.intValue();
		System.out.println(x);
		long y = J.longValue();
		System.out.println(y);
		double d =	J.doubleValue();
		System.out.println(d);
		
		String l = N.toString();
		System.out.println(l);//123456
		//wrapper class
		Double d1 = new Double(d);
		System.out.println(d1);
		
		

	}

}

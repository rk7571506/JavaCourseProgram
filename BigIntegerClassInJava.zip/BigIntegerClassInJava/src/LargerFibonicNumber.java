import java.math.BigInteger;

public class LargerFibonicNumber {

  public static BigInteger calculateLargeFibo(long n)
  {
	  BigInteger a = BigInteger.valueOf(0);
	  BigInteger b = BigInteger.valueOf(1);
	  BigInteger c = BigInteger.valueOf(1);
	  
	  for(int i=2;i<=n;i++)
	  {
		  c = a.add(b);
		  a = b;
		  b = c;
	  }
	  
	  return a;
  }
	
	public static void main(String[] args) {
		
		long n = 10000L;
		System.out.println(calculateLargeFibo(n));
		System.out.println();
		System.out.println();
		
		System.out.println(calculateLargeFibo(100));
		
		System.out.println(calculateLargeFibo(1));
		System.out.println(calculateLargeFibo(2));
		System.out.println(calculateLargeFibo(3));

	}

}

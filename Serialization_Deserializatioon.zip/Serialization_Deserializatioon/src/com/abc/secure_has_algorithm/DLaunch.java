package com.abc.secure_has_algorithm;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name1;
	int age;
	int runs;
	float avg;
	
	public Cricketer(String name1, int age,int runs,float avg)
	{
		this.name1 = name1;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	final static long serialVersionUID = 100;
	
	public void disp()
	{
		System.out.println(name1);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
		
	}
	
	private void writeObject(ObjectOutputStream oos) throws IOException
	{
			oos.writeInt(age);
			oos.writeFloat(avg);
	}
	
	private void readObject(ObjectInputStream ois) throws IOException
	{
		age = ois.readInt();
		avg = ois.readFloat();
	}
	
}
public class DLaunch {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\e3.txt";
		FileInputStream fis = new FileInputStream(path);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Cricketer	c  = (Cricketer)(ois).readObject();
		c.disp();

	}

}

package com.abc.selectedserialzation_externalizable;

import java.io.Externalizable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

class Cricketer implements Externalizable
{
	String name;
	int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age,int runs,float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
		
	}
	
	public void writeExternal(ObjectOutput oo) throws IOException
	{
			oo.writeInt(age);
			oo.writeFloat(avg);
	}
	
	public void readExternal(ObjectInput oi) throws IOException
	{
		age = oi.readInt();
		avg = oi.readFloat();
	}
	
	public Cricketer()
	{
		
	}
}

public class SLaunch {

	public static void main(String[] args) throws IOException {
		
		Cricketer c = new Cricketer("Ravi",19,450,45.6f);
		c.disp();
		
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\e1.txt";
		
		FileOutputStream fos = new FileOutputStream(path);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(c);	
	}

}

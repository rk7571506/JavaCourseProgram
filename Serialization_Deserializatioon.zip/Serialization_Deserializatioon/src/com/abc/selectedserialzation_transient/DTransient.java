package com.abc.selectedserialzation_transient;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name;
	transient int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age , int runs , float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
	}
}

public class DTransient {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\stransient.txt";
		FileInputStream fis = new  FileInputStream(path);
		ObjectInputStream oos = new ObjectInputStream(fis);
		
		Cricketer c	= (Cricketer)(oos).readObject();
		
		c.disp();

	}

}

package com.abc.selectedserialzation_transient;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name;
	transient int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age , int runs , float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
	}
}

public class STransient {

	public static void main(String[] args) throws IOException {
		Cricketer c = new Cricketer("Ravi",20,560,56.89f);
		c.disp();
		
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\stransient.txt";
		
		FileOutputStream fos = new FileOutputStream(path);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(c);
	}

}

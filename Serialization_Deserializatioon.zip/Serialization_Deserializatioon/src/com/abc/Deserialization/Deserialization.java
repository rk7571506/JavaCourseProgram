package com.abc.Deserialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name;
	int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age,int runs,float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
		
	}
}

public class Deserialization {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\Program2serializalbe.txt";
		FileInputStream fis = new FileInputStream(path);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
	   Cricketer c  = (Cricketer)(ois.readObject());
	   	c.disp();
	}

}

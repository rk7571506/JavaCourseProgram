package com.abc.Deserialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name;
	int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age,int runs,float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
		
	}
}

public class Serialization1 {

	public static void main(String[] args) throws IOException  {
		Cricketer c = new Cricketer("Ravi", 20, 1200, 560.5f);
		c.disp();
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\Program2serializalbe.txt";
		FileOutputStream fos = new FileOutputStream(path);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(c);

	}

}

package com.abc.selectedserialzation_serializable;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Cricketer implements Serializable
{
	String name;
	int age;
	int runs;
	float avg;
	
	public Cricketer(String name, int age,int runs,float avg)
	{
		this.name = name;
		this.age = age;
		this.runs = runs;
		this.avg = avg;
	}
	
	public void disp()
	{
		System.out.println(name);
		System.out.println(age);
		System.out.println(runs);
		System.out.println(avg);
		
	}
	
	private void writeObject(ObjectOutputStream oos) throws IOException
	{
			oos.writeInt(age);
			oos.writeFloat(avg);
	}
	
	private void readObject(ObjectInputStream ois) throws IOException
	{
		age = ois.readInt();
		avg = ois.readFloat();
	}
	
}

public class SLanuch {

	public static void main(String[] args) throws IOException {
		
		Cricketer c = new Cricketer("Ravi",34,67,20.6f);
		c.disp();
		
		String path = "F:\\Coading\\Java\\EclipseEE_Project\\Serialization_Deserializatioon\\TextFile\\e2.txt";
		
		FileOutputStream fos = new FileOutputStream(path);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(c);		
		

	}

}
